I wanted to add a shopping cart to my page, so I built off of the original code. 

# Shopping order with pure javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/dcergo/pen/RawpJL](https://codepen.io/dcergo/pen/RawpJL).

