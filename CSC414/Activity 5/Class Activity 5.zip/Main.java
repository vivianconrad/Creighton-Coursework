class Main {

  static void converter(int decimalNumber){
    int[] binaryNum = new int[1000];
    int i = 0;
    while (decimalNumber > 0) {
      binaryNum[i] = decimalNumber % 2;
      decimalNumber = decimalNumber / 2;
      i++;
    }
   
    for (int j = i - 1; j >= 0; j--){
      System.out.print(binaryNum[j]);
    } 
  }

  public static void main(String[] args) {
    int decimal = 10;
    System.out.println("Decimal of " + decimal + " is:");
    converter(decimal);
  }
}